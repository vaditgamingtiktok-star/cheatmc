#pragma once
#include <cmath>
#include <ctime>
#include <android/log.h>

#define LOG_TAG "CHEATMC"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

struct Vector3 {
    float x, y, z;
    Vector3() : x(0), y(0), z(0) {}
    Vector3(float x, float y, float z) : x(x), y(y), z(z) {}
    
    float Distance(const Vector3& other) {
        float dx = x - other.x;
        float dy = y - other.y;
        float dz = z - other.z;
        return sqrt(dx*dx + dy*dy + dz*dz);
    }
};

struct Entity {
    uintptr_t address;
    Vector3 pos;
    int health;
    bool valid;
    float dist;
    int hitCount;      // Counter untuk hit combo
    bool wasHit;       // Status kena hit
    time_t lastHitTime;
};