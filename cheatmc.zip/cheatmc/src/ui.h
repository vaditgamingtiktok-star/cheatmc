#pragma once
#include "aimbot.h"
#include "features.h"

class UIMenu {
private:
    bool visible = false;
    Aimbot* aimbot;
    Features* features;
    
public:
    UIMenu(Aimbot* ab, Features* ft) : aimbot(ab), features(ft) {}
    
    void Toggle() { visible = !visible; }
    bool IsVisible() { return visible; }
    
    void Render();
    void HandleKey(int keyCode, bool down);
};