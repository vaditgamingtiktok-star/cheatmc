#pragma once
#include "memory.h"
#include <vector>
#include <algorithm>

class Aimbot {
private:
    Memory* mem;
    std::vector<Entity> entities;
    std::mutex entityMutex;
    
    // Settings
    bool enabled = false;
    float fov = 15.0f;
    float range = 5.0f;           // 1-7 block
    float speed = 3.0f;            // 2-5 speed
    bool aimToBody = true;         // Badan, bukan kepala
    float bodyHeight = 1.2f;       // Ketinggian badan (perut)
    
public:
    Aimbot(Memory* memory) : mem(memory) {}
    
    void ScanEntities();
    void Update(float* angles);
    Vector3 CalcAngles(const Vector3& src, const Vector3& dst);
    float GetAngleDist(const Vector3& a1, const Vector3& a2);
    
    // Setters
    void SetEnabled(bool state) { enabled = state; }
    void SetFOV(float val) { fov = val; }
    void SetRange(float val) { range = val; }
    void SetSpeed(float val) { speed = val; }
    
    // Getters
    bool IsEnabled() { return enabled; }
    float GetFOV() { return fov; }
    float GetRange() { return range; }
    float GetSpeed() { return speed; }
    int GetEntityCount() { return entities.size(); }
};