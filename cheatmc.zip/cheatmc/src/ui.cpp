#include "ui.h"
#include "imgui/imgui.h"

void UIMenu::Render() {
    if (!visible) return;
    
    ImGui::SetNextWindowPos(ImVec2(50, 50), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(400, 500), ImGuiCond_FirstUseEver);
    
    ImGui::Begin("CheatMC v1.0", &visible);
    
    // Header
    ImGui::Text("Minecraft 1.26.2.1");
    ImGui::Separator();
    
    // Aimbot Section
    if (ImGui::CollapsingHeader("Aimbot", ImGuiTreeNodeFlags_DefaultOpen)) {
        bool state = aimbot->IsEnabled();
        if (ImGui::Checkbox("Enable Aimbot", &state)) {
            aimbot->SetEnabled(state);
        }
        
        float fov = aimbot->GetFOV();
        if (ImGui::SliderFloat("FOV", &fov, 1.0f, 90.0f)) {
            aimbot->SetFOV(fov);
        }
        
        float range = aimbot->GetRange();
        if (ImGui::SliderFloat("Range", &range, 1.0f, 7.0f)) {
            aimbot->SetRange(range);
        }
        
        float speed = aimbot->GetSpeed();
        if (ImGui::SliderFloat("Speed", &speed, 2.0f, 5.0f)) {
            aimbot->SetSpeed(speed);
        }
        
        ImGui::Text("Aim to: Body");
        ImGui::Text("Entities: %d", aimbot->GetEntityCount());
    }
    
    // Auto Zoom
    if (ImGui::CollapsingHeader("Auto Zoom")) {
        bool state = features->GetSettings().zoomEnabled;
        if (ImGui::Checkbox("Enable Auto Zoom (C key)", &state)) {
            features->GetSettings().zoomEnabled = state;
        }
        
        ImGui::SliderFloat("Zoom FOV", &features->GetSettings().zoomFOV, 20.0f, 60.0f);
        ImGui::Text("Press C to zoom");
    }
    
    // Auto Jump Reset
    if (ImGui::CollapsingHeader("Auto Jump Reset")) {
        bool state = features->GetSettings().jumpResetEnabled;
        if (ImGui::Checkbox("Enable Jump Reset (F7 toggle)", &state)) {
            features->GetSettings().jumpResetEnabled = state;
        }
        
        ImGui::SliderFloat("Range", &features->GetSettings().jumpRange, 1.0f, 7.0f);
        ImGui::SliderInt("Hit Interval", &features->GetSettings().jumpInterval, 2, 8);
        ImGui::Text("Reset on hits: 2,4,6,...");
    }
    
    // Auto STap
    if (ImGui::CollapsingHeader("Auto S-Tap")) {
        bool state = features->GetSettings().sTapEnabled;
        if (ImGui::Checkbox("Enable S-Tap (F6 toggle)", &state)) {
            features->GetSettings().sTapEnabled = state;
        }
        
        ImGui::SliderFloat("Range", &features->GetSettings().sTapRange, 1.0f, 7.0f);
        ImGui::SliderFloat("Combo Height", &features->GetSettings().sTapHeight, 2.0f, 5.0f);
        ImGui::Text("Auto hold S when combo detected");
    }
    
    // Auto Clicker
    if (ImGui::CollapsingHeader("Auto Clicker")) {
        bool state = features->GetSettings().clickerEnabled;
        if (ImGui::Checkbox("Enable Clicker (F toggle)", &state)) {
            features->GetSettings().clickerEnabled = state;
        }
        
        ImGui::SliderFloat("Range", &features->GetSettings().clickerRange, 1.0f, 7.0f);
        ImGui::Text("Auto clicks + place blocks");
        ImGui::Text("~20 clicks/sec");
    }
    
    // Status
    ImGui::Separator();
    ImGui::Text("F1: Hide/Show Menu");
    ImGui::Text("F6: Toggle S-Tap");
    ImGui::Text("F7: Toggle Jump Reset");
    ImGui::Text("C: Zoom (hold)");
    ImGui::Text("F: Clicker (hold)");
    
    ImGui::End();
}

void UIMenu::HandleKey(int keyCode, bool down) {
    // Key handling diimplement di main
}