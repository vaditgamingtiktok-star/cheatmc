#pragma once
#include "utils.h"
#include <dlfcn.h>
#include <vector>
#include <mutex>
#include <exception>

namespace Offsets {
    // OFFSET UNTUK v1.26.2.1 (UPDATE TERBARU)
    const uintptr_t LOCAL_PLAYER_PTR = 0x04F8A4C4;    // Berubah dikit
    const uintptr_t VIEW_ANGLES = 0x04F8A4C8;        // Camera rotation
    const uintptr_t ENTITY_LIST = 0x04F8A4E0;        // List entities
    const int MAX_ENTITIES = 200;
    const uintptr_t IS_IN_GAME = 0x04F8A500;         // Status lagi di server/game
    
    namespace Entity {
        const uintptr_t POS_X = 0x80;
        const uintptr_t POS_Y = 0x84;
        const uintptr_t POS_Z = 0x88;
        const uintptr_t HEALTH = 0x1A0;
        const uintptr_t IS_VALID = 0x1A4;
        const uintptr_t NAME = 0x1C0;
        const uintptr_t GROUND_STATE = 0x1E0;        // Buat deteksi di ground
        const uintptr_t VELOCITY = 0x1F0;             // Buat deteksi combo
        const uintptr_t ATTACK_TIMER = 0x210;         // Buat hit counter
    }
}

class Memory {
private:
    void* libHandle;
    uintptr_t baseAddress;
    std::mutex memMutex;
    
public:
    bool Initialize() {
        std::lock_guard<std::mutex> lock(memMutex);
        libHandle = dlopen("libminecraft.so", RTLD_NOW);
        if (!libHandle) return false;
        
        Dl_info info;
        dladdr((void*)Offsets::LOCAL_PLAYER_PTR, &info);
        baseAddress = (uintptr_t)info.dli_fbase;
        return true;
    }
    
    bool IsInGame() {
        try {
            return Read<bool>(Offsets::IS_IN_GAME);
        } catch (...) {
            return false;
        }
    }
    
    template<typename T>
    T Read(uintptr_t addr) {
        return *(T*)addr;
    }
    
    template<typename T>
    void Write(uintptr_t addr, T val) {
        *(T*)addr = val;
    }
};