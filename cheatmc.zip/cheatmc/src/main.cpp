#include <pthread.h>
#include <unistd.h>
#include <android_native_app_glue.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include "aimbot.h"
#include "features.h"
#include "ui.h"

// ImGui headers (download sendiri)
#include "imgui/imgui.h"
#include "imgui/imgui_impl_android.h"
#include "imgui/imgui_impl_opengl3.h"

// Global objects
Memory g_Memory;
Aimbot* g_Aimbot = nullptr;
Features* g_Features = nullptr;
UIMenu* g_UIMenu = nullptr;

ANativeWindow* g_Window = nullptr;
bool g_Running = true;

// Key states (simulasi input)
bool g_Keys[512] = {false};
bool g_ZoomActive = false;
bool g_ClickerActive = false;

// Render thread
void* RenderThread(void*) {
    LOGI("Render thread started");
    
    // Setup EGL
    EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(display, 0, 0);
    
    EGLConfig config;
    EGLint numConfigs;
    const EGLint attribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 16,
        EGL_NONE
    };
    eglChooseConfig(display, attribs, &config, 1, &numConfigs);
    
    EGLSurface surface = eglCreateWindowSurface(display, config, g_Window, nullptr);
    
    EGLint contextAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    EGLContext context = eglCreateContext(display, config, EGL_NO_CONTEXT, contextAttribs);
    
    eglMakeCurrent(display, surface, surface, context);
    
    // Setup ImGui
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.Fonts->AddFontDefault();
    
    ImGui::StyleColorsDark();
    
    ImGui_ImplAndroid_Init(g_Window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    
    // Main render loop
    while (g_Running) {
        // Start ImGui frame
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplAndroid_NewFrame();
        ImGui::NewFrame();
        
        // Render UI
        if (g_UIMenu && g_UIMenu->IsVisible()) {
            g_UIMenu->Render();
        }
        
        // Render
        glViewport(0, 0, ANativeWindow_getWidth(g_Window), ANativeWindow_getHeight(g_Window));
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        
        eglSwapBuffers(display, surface);
        usleep(16000); // ~60 FPS
    }
    
    // Cleanup
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();
    
    eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    eglDestroySurface(display, surface);
    eglDestroyContext(display, context);
    
    return nullptr;
}

// Cheat thread
void* CheatThread(void*) {
    LOGI("Cheat thread started");
    
    if (!g_Memory.Initialize()) {
        LOGE("Failed to init memory");
        return nullptr;
    }
    
    g_Aimbot = new Aimbot(&g_Memory);
    g_Features = new Features(&g_Memory);
    g_Features->Start();
    
    float angles[2];
    
    while (g_Running) {
        if (g_Memory.IsInGame()) {
            // Update entities
            g_Aimbot->ScanEntities();
            
            // Read angles
            angles[0] = g_Memory.Read<float>(Offsets::VIEW_ANGLES);
            angles[1] = g_Memory.Read<float>(Offsets::VIEW_ANGLES + 4);
            
            // Update aimbot
            g_Aimbot->Update(angles);
            
            // Handle keys untuk features
            auto& sets = g_Features->GetSettings();
            
            // Zoom dengan C key
            if (g_Keys[sets.zoomKey]) {
                sets.zoomEnabled = true;
            } else {
                sets.zoomEnabled = false;
            }
            
            // Clicker dengan F key
            if (g_Keys[sets.clickerKey]) {
                sets.clickerEnabled = true;
            } else {
                sets.clickerEnabled = false;
            }
        }
        
        usleep(50000); // 50ms
    }
    
    return nullptr;
}

// Input handling
void HandleKey(int keyCode, bool down) {
    if (keyCode >= 0 && keyCode < 512) {
        g_Keys[keyCode] = down;
    }
    
    // Toggle menu dengan F1 (282)
    if (keyCode == 282 && down && g_UIMenu) {
        g_UIMenu->Toggle();
    }
    
    // Toggle S-Tap dengan F6 (287)
    if (keyCode == 287 && down && g_Features) {
        g_Features->ToggleSTap();
    }
    
    // Toggle Jump Reset dengan F7 (288)
    if (keyCode == 288 && down && g_Features) {
        g_Features->ToggleJumpReset();
    }
}

// Native activity callbacks
void onAppCmd(struct android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            g_Window = app->window;
            pthread_t renderThread;
            pthread_create(&renderThread, nullptr, RenderThread, nullptr);
            pthread_detach(renderThread);
            break;
        case APP_CMD_TERM_WINDOW:
            g_Window = nullptr;
            break;
    }
}

int32_t onInputEvent(struct android_app* app, AInputEvent* event) {
    if (AInputEvent_getType(event) == AINPUT_EVENT_TYPE_KEY) {
        int32_t keyCode = AKeyEvent_getKeyCode(event);
        int32_t action = AKeyEvent_getAction(event);
        
        if (action == AKEY_EVENT_ACTION_DOWN) {
            HandleKey(keyCode, true);
        } else if (action == AKEY_EVENT_ACTION_UP) {
            HandleKey(keyCode, false);
        }
    }
    return 1;
}

// Entry point
void android_main(struct android_app* app) {
    app->onAppCmd = onAppCmd;
    app->onInputEvent = onInputEvent;
    
    // Start cheat thread
    pthread_t cheatThread;
    pthread_create(&cheatThread, nullptr, CheatThread, nullptr);
    pthread_detach(cheatThread);
    
    // Create UI
    g_UIMenu = new UIMenu(g_Aimbot, g_Features);
    
    // Main loop
    while (true) {
        int ident;
        int events;
        struct android_poll_source* source;
        
        while ((ident = ALooper_pollAll(0, nullptr, &events, (void**)&source)) >= 0) {
            if (source) source->process(app, source);
        }
        
        usleep(100000);
    }
}