#include "features.h"
#include <unistd.h>
#include <ctime>

Features::Features(Memory* memory) : mem(memory), running(false) {}

Features::~Features() {
    Stop();
}

void Features::ProcessZoom() {
    // Auto zoom: ngubah FOV pas pencet key
    uintptr_t localPtr = mem->Read<uintptr_t>(Offsets::LOCAL_PLAYER_PTR);
    if (!localPtr) return;
    
    static float originalFOV = 70.0f;
    static bool wasZooming = false;
    
    // Cek key ditekan (di sini simulasi, nanti di main.cpp konek ke input)
    // Untuk sementara pake flag
    
    if (sets.zoomEnabled) {
        if (!wasZooming) {
            originalFOV = mem->Read<float>(0x04F8A600);  // Address FOV
            mem->Write<float>(0x04F8A600, sets.zoomFOV);
            wasZooming = true;
        }
    } else {
        if (wasZooming) {
            mem->Write<float>(0x04F8A600, originalFOV);
            wasZooming = false;
        }
    }
}

void Features::ProcessJumpReset() {
    uintptr_t localPtr = mem->Read<uintptr_t>(Offsets::LOCAL_PLAYER_PTR);
    if (!localPtr) return;
    
    static int hitCounter = 0;
    static time_t lastHit = 0;
    
    // Baca apakah kena hit
    int hitStatus = mem->Read<int>(localPtr + 0x230);  // Address hit status
    
    if (hitStatus > 0 && time(nullptr) - lastHit > 1) {
        hitCounter++;
        lastHit = time(nullptr);
        
        // Reset setiap hit ke-2,4,6,...
        if (hitCounter % sets.jumpInterval == 0) {
            // Trigger jump
            mem->Write<int>(localPtr + 0x240, 1);  // Address jump flag
        }
        
        if (hitCounter > 20) hitCounter = 0;
    }
}

void Features::ProcessSTap() {
    uintptr_t localPtr = mem->Read<uintptr_t>(Offsets::LOCAL_PLAYER_PTR);
    if (!localPtr) return;
    
    // Baca velocity Y (naiknya)
    float velY = mem->Read<float>(localPtr + Offsets::Entity::VELOCITY + 4);
    
    // Kalau naik tinggi (combo) dan baru hit ke 1-2
    if (velY > sets.sTapHeight) {
        int hitStatus = mem->Read<int>(localPtr + 0x230);
        if (hitStatus <= 2 && !sets.sTapActive) {
            sets.sTapActive = true;
            sets.sTapStartTime = time(nullptr);
            
            // Tekan S mundur selama 1 detik
            // Ini nantinya di main thread yang handle input
        }
    }
    
    // Matikan setelah 1 detik
    if (sets.sTapActive && time(nullptr) - sets.sTapStartTime > 1) {
        sets.sTapActive = false;
    }
}

void Features::ProcessClicker() {
    if (!sets.clickerEnabled) return;
    
    // Auto click: simulasi tap di layar
    // Kecepatan 10-20 clicks per second
    static time_t lastClick = 0;
    
    if (time(nullptr) - lastClick > 0.05) {  // 20 CPS
        // Trigger click
        mem->Write<int>(0x04F8A700, 1);  // Address click flag
        lastClick = time(nullptr);
    }
}

void Features::Start() {
    running = true;
    featureThread = new std::thread([this]() {
        while (running) {
            if (sets.zoomEnabled) ProcessZoom();
            if (sets.jumpResetEnabled) ProcessJumpReset();
            if (sets.sTapEnabled) ProcessSTap();
            if (sets.clickerEnabled) ProcessClicker();
            
            usleep(50000);  // 50ms
        }
    });
}

void Features::Stop() {
    running = false;
    if (featureThread) {
        featureThread->join();
        delete featureThread;
    }
}