#pragma once
#include "memory.h"
#include <atomic>
#include <thread>

struct FeatureSettings {
    // Auto Aim (udah di aimbot)
    
    // Auto Zoom
    bool zoomEnabled = false;
    int zoomKey = 295;  // C key
    float zoomFOV = 30.0f;
    
    // Auto Jump Reset
    bool jumpResetEnabled = false;
    int jumpKey = 296;  // Space
    float jumpRange = 5.0f;
    int jumpInterval = 2;  // Hit ke-2,4,6...
    int currentHits = 0;
    
    // Auto STap
    bool sTapEnabled = false;
    int sTapKey = 293;  // S key
    float sTapRange = 5.0f;
    float sTapHeight = 3.5f;  // Tinggi combo
    bool sTapActive = false;
    time_t sTapStartTime;
    
    // Auto Clicker
    bool clickerEnabled = false;
    int clickerKey = 294;  // F key
    float clickerRange = 5.0f;
    bool clicking = false;
};

class Features {
private:
    Memory* mem;
    FeatureSettings sets;
    std::atomic<bool> running;
    std::thread* featureThread;
    
    void ProcessZoom();
    void ProcessJumpReset();
    void ProcessSTap();
    void ProcessClicker();
    
public:
    Features(Memory* memory);
    ~Features();
    
    void Start();
    void Stop();
    
    FeatureSettings& GetSettings() { return sets; }
    
    // Toggle functions
    void ToggleZoom() { sets.zoomEnabled = !sets.zoomEnabled; }
    void ToggleJumpReset() { sets.jumpResetEnabled = !sets.jumpResetEnabled; }
    void ToggleSTap() { sets.sTapEnabled = !sets.sTapEnabled; }
    void ToggleClicker() { sets.clickerEnabled = !sets.clickerEnabled; }
};