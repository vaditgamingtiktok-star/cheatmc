#include "aimbot.h"

void Aimbot::ScanEntities() {
    std::lock_guard<std::mutex> lock(entityMutex);
    entities.clear();
    
    uintptr_t localPtr = mem->Read<uintptr_t>(Offsets::LOCAL_PLAYER_PTR);
    if (!localPtr) return;
    
    Vector3 localPos;
    localPos.x = mem->Read<float>(localPtr + Offsets::Entity::POS_X);
    localPos.y = mem->Read<float>(localPtr + Offsets::Entity::POS_Y);
    localPos.z = mem->Read<float>(localPtr + Offsets::Entity::POS_Z);
    
    for (int i = 0; i < Offsets::MAX_ENTITIES; i++) {
        uintptr_t entPtr = mem->Read<uintptr_t>(Offsets::ENTITY_LIST + (i * 4));
        if (!entPtr) continue;
        
        bool valid = mem->Read<bool>(entPtr + Offsets::Entity::IS_VALID);
        if (!valid) continue;
        
        int hp = mem->Read<int>(entPtr + Offsets::Entity::HEALTH);
        if (hp <= 0) continue;
        
        Entity ent;
        ent.address = entPtr;
        ent.pos.x = mem->Read<float>(entPtr + Offsets::Entity::POS_X);
        ent.pos.y = mem->Read<float>(entPtr + Offsets::Entity::POS_Y);
        ent.pos.z = mem->Read<float>(entPtr + Offsets::Entity::POS_Z);
        ent.health = hp;
        ent.valid = true;
        ent.dist = localPos.Distance(ent.pos);
        
        // Filter berdasarkan range
        if (ent.dist > range && range > 0) continue;
        
        entities.push_back(ent);
    }
}

Vector3 Aimbot::CalcAngles(const Vector3& src, const Vector3& dst) {
    Vector3 angles;
    float dx = dst.x - src.x;
    float dy = (dst.y - src.y) - bodyHeight;  // Kurangi biar ke badan
    float dz = dst.z - src.z;
    float dist = sqrt(dx*dx + dy*dy + dz*dz);
    
    angles.y = atan2(dz, dx) * (180.0f / M_PI) - 90.0f;
    angles.x = -atan2(dy, dist) * (180.0f / M_PI);
    
    if (angles.y < -180) angles.y += 360;
    if (angles.y > 180) angles.y -= 360;
    
    return angles;
}

float Aimbot::GetAngleDist(const Vector3& a1, const Vector3& a2) {
    float dyaw = abs(a1.y - a2.y);
    float dpitch = abs(a1.x - a2.x);
    if (dyaw > 180) dyaw = 360 - dyaw;
    return sqrt(dyaw*dyaw + dpitch*dpitch);
}

void Aimbot::Update(float* angles) {
    if (!enabled) return;
    
    std::lock_guard<std::mutex> lock(entityMutex);
    if (entities.empty()) return;
    
    uintptr_t localPtr = mem->Read<uintptr_t>(Offsets::LOCAL_PLAYER_PTR);
    if (!localPtr) return;
    
    Vector3 localPos;
    localPos.x = mem->Read<float>(localPtr + Offsets::Entity::POS_X);
    localPos.y = mem->Read<float>(localPtr + Offsets::Entity::POS_Y);
    localPos.z = mem->Read<float>(localPtr + Offsets::Entity::POS_Z);
    
    Vector3 currentAng(angles[0], angles[1], 0);
    
    Entity* best = nullptr;
    float bestScore = FLT_MAX;
    
    for (auto& e : entities) {
        Vector3 targetAng = CalcAngles(localPos, e.pos);
        float angleDist = GetAngleDist(currentAng, targetAng);
        
        if (angleDist > fov) continue;
        
        float score = angleDist + (e.dist * 0.1f);
        if (score < bestScore) {
            bestScore = score;
            best = &e;
        }
    }
    
    if (best) {
        Vector3 targetAng = CalcAngles(localPos, best->pos);
        
        // Smooth aim
        if (speed > 0) {
            angles[0] += (targetAng.x - angles[0]) / speed;
            angles[1] += (targetAng.y - angles[1]) / speed;
        } else {
            angles[0] = targetAng.x;
            angles[1] = targetAng.y;
        }
        
        if (angles[1] < -180) angles[1] += 360;
        if (angles[1] > 180) angles[1] -= 360;
        
        mem->Write<float>(Offsets::VIEW_ANGLES, angles[0]);
        mem->Write<float>(Offsets::VIEW_ANGLES + 4, angles[1]);
    }
}